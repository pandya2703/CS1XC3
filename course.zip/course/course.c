#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief the following function enrolls the student into the course
 * 
 * @param course the course we want to enroll the student into
 * @param student  the student we want to enroll into the given course
 */
void enroll_student(Course *course, Student *student)
{
  // the if condition checks if this the first student being enrolled in the course
  // if it is the first ever student then space sufficient for a student is allocated. 
  // if it is not the first ever student to be enrolled, then realloc is used to reallocate more space for the student

  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief print_course simply prints out all the information about a particular course
 * 
 * @param course the course we want to print information about =
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");

  // prints all the students and their information who are in the corurse
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief returns the student with the highest average. If no students available then returns NULL
 * 
 * @param course the name of the course for which we want to find the top student
 * @return Student* student with the highest average in the course
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];

  // this for loops goes through all the students in the given course and calculates their averages. 
  // if the current student's average is greater than the previous maximum average then that student's average is assigned
  // to the maximium average variable
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief the following function checks whether the students in the course are passing the course or not
 * 
 * @param course the name of the course for which we want to find out how many students are passing
 * @param total_passing the total number of stuents who are passing the coure
 * @return Student* returns an array of studnets who are passing the course
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  // the following for loop checks whether each students average is greater than 50
  // and if so then 1 is added to the count
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  // if the student's average is greater than 50 then they are considered as passing. 
  // if the student is passing then they are added to the passing array. 
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}