 
/**
 * @brief Struct student is a data structure which contains the first name, the last name and the id of the student. 
 * It also contains an array containing all the grades of the student and also how many grades that student has
 * 
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
