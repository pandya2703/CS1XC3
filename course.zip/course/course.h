#include "student.h"
#include <stdbool.h>
 

/**
 * @brief This is a special data structure which takes the name of the course, the course code, 
 * name of the student and total number of students
 * 
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


